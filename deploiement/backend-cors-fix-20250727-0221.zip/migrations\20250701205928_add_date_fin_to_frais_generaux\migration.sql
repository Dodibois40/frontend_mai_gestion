-- AlterTable
ALTER TABLE "frais_generaux" ADD COLUMN "dateFin" DATETIME;
