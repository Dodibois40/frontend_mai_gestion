-- AlterTable
ALTER TABLE "user_profiles" ADD COLUMN "adresse" TEXT;
ALTER TABLE "user_profiles" ADD COLUMN "codePostal" TEXT;
ALTER TABLE "user_profiles" ADD COLUMN "dateNaissance" DATETIME;
ALTER TABLE "user_profiles" ADD COLUMN "ville" TEXT;
